This directory is meant to be used for storing prebundled JSON templates in Bloks. If you have any
questions how to generate a template or utilize prebundling for Bloks, please reach out to Josh
Leibsly or Apoorva Arunkumar.
